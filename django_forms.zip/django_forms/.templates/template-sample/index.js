export default function __templateNameToPascalCase__() {
  console.log("TemplateName -> __templateName__");
  console.log("TemplateName to ParamCase -> __templateNameToParamCase__");
  console.log("TemplateName to PascalCase -> __templateNameToPascalCase__");
}
