from django.http.response import HttpResponseRedirect
from django.contrib import messages
from django.shortcuts import redirect, render
from django.http import HttpResponse
from myapp.forms import ContactForm,SnippetForm,Career,contactHere
from .models import Snippet, Contact, ApplyForm, ContactHere, Employee
from django.conf import settings
from django.core.files.storage import FileSystemStorage
import re
from django.shortcuts import get_object_or_404
from rest_framework import serializers, status
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import EmployeeSerializer
from rest_framework.permissions import IsAuthenticated

# from somewhere import handle_uploaded_file
# Create your views here.
def contact(request):
    if  request.method == "POST":
        form = ContactForm(request.POST)
        if form.is_valid():
            obj = Contact()
            obj.name = form.cleaned_data['name']
            obj.email = form.cleaned_data['email']
            obj.category = form.cleaned_data['category']
            obj.subject = form.cleaned_data['subject']
            obj.body = form.cleaned_data['body']
            obj.save()
    form = ContactForm()
    return render(request,'form.html',{"form":form})

def Snippet_details(request):
    if  request.method == "POST":
        form = SnippetForm(request.POST)
        if form.is_valid():
            s = Snippet()
            s.name = form.cleaned_data['name']
            s.body = form.cleaned_data['body']
            s.save()
    form = SnippetForm()
    return render(request,'form.html',{"form":form})

def applyHere(request):
    if request.method == 'POST':
        form = Career(request.POST,request.FILES)
        if form.is_valid():
            file = request.FILES['resume']
            obj = ApplyForm()
            obj.full_name = form.cleaned_data['full_name']
            obj.father_name = form.cleaned_data['father_name']
            obj.qualification = form.cleaned_data['qualification']
            obj.email = form.cleaned_data['email']
            obj.contact = form.cleaned_data['contact']
            obj.position = form.cleaned_data['position']
            obj.resume = form.cleaned_data['resume']
            obj.save()
            messages.success(request, "Your data has been saved!")
            return HttpResponseRedirect(request.path,'/career')
        else:
            return render(request, 'apply.html', {'form':form})
        
    form = Career()
    return render(request,'apply.html',{'form':form})

def career(request):
    return render(request,'applyhere.html')


#api view
class Employeeview(APIView):
    # permission_classes = (IsAuthenticated,)
    
    def get(self,request):
        employeeM = Employee.objects.all()
        ser = EmployeeSerializer(employeeM,many=True)
        return Response(ser.data)
    
    def post(self,request):
        ser = EmployeeSerializer(data=request.data)
        if ser.is_valid():
            ser.save()
            return Response(ser.data)
        return Response(ser.errors)

    
def Contacthere(request):
    if request.method == 'POST':
        form = contactHere(request.POST)
        if form.is_valid():
            obj = ContactHere()
            obj.name = form.cleaned_data['name']
            obj.email = form.cleaned_data['email']
            obj.message = form.cleaned_data['message']
            obj.save()
            messages.success(request, "Thank You for contacting us.")
            return HttpResponseRedirect(request.path,'/contact')
        else:
            return render(request, 'teckcontact.html', {'form':form})
        
    form = contactHere()
    return render(request,'teckcontact.html',{'form':form})
    # if request.method == "POST":
    #     string_check = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
    #     print('name is:',request.POST.get('name'))
    #     if any(i.isdigit() for i in request.POST.get('name')) == True:
    #         messages.info(request,'Please enter valid name.')
    #         return redirect('/contact')
    #     elif string_check.search(request.POST.get('name')) != None:
    #         pass
        
    #     contact = ContactHere()
    #     contact.name = request.POST.get('name')
    #     contact.email = request.POST.get('email')
    #     contact.message = request.POST.get('message')
    #     contact.save()
    #     messages.success(request, x"Thank You for contacting us.")
    #     return HttpResponseRedirect(request.path,'/contact')
    # return render(request,'teckcontact.html')