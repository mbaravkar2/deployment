from django_forms.settings import LANGUAGE_CODE
from django import forms
from .models import ContactHere, Snippet,ApplyForm
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout,Submit,Row
import re 

class ContactForm(forms.Form):
    name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Full Name'}))
    email = forms.EmailField(label='E-Mail',widget=forms.TextInput(attrs={'placeholder': 'Email'}))
    category = forms.ChoiceField(choices=[('Question','question'),('Other','other')])
    subject = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Subject'}))
    body = forms.CharField(widget=forms.Textarea,)
    
    def __init__(self,*args, **kwargs):
        super().__init__(*args,**kwargs)
        
        
        self.helper = FormHelper
        self.helper.form_class = 'form'
        self.helper.label_class = 'col-lg-8'
        self.helper.field_class = 'col-lg-10'
        self.helper.form_method = 'post'
        self.helper.layout = Layout(
            Row(
                'name',css_class='form-row ml-5'
            ),
             Row(
                'email',css_class='form-row ml-5'
            ),
              Row(
                'category',css_class='form-row ml-5'
            ),
               Row(
                'subject',css_class='form-row ml-5'
            ),
                Row(
                'body',css_class='form-row ml-5'
            )
            ,Submit('submit','submit',css_class='btn-success ml-5')
        )
        
class Career(forms.ModelForm):
    class Meta:
        model = ApplyForm
        fields = ('full_name','father_name','qualification','email','contact','position','resume')
        labels = {
            'full_name': 'Full Name','email':'E-mail','contact':'Mobile No'
        }
        
    def __init__(self,*args, **kwargs):
        super().__init__(*args,**kwargs)
        
        self.helper = FormHelper
        self.helper.form_method = 'post'
        self.helper.layout = Layout(
            'full_name','father_name','qualification','email','contact','position','resume',Submit('submit','submit',css_class='btn-sucess')
        )
    
    def clean(self):
        string_check = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
        
        super(Career, self).clean()
        full_name = self.cleaned_data.get('full_name')
        father_name = self.cleaned_data.get('father_name')
        qualification = self.cleaned_data.get('qualification')
        contact = self.cleaned_data.get('contact')
        email = self.cleaned_data.get('email')
        
        if any(i.isdigit() for i in full_name) == True:
            self._errors['full_name'] = self.error_class(['Please enter valid string'])
        elif string_check.search(full_name) != None:
            self._errors['full_name'] = self.error_class(['Special character not allowed'])
        elif (len(full_name.split()) < 2 or len(full_name.split())>2):
            self._errors['full_name'] = self.error_class(['Please enter valid full name'])
            
        if  any(i.isdigit() for i in father_name) == True:
            self._errors['father_name'] = self.error_class(['Please enter valid string'])
        elif string_check.search(father_name) != None:
            self._errors['father_name'] = self.error_class(['Special character not allowed'])
        
        if any(i.isdigit() for i in qualification)== True:
            self._errors['qualification'] = self.error_class(['Please enter valid string'])
        elif string_check.search(qualification) != None:
            self._errors['qualification'] = self.error_class(['Special character not allowed'])
        
        if contact.isnumeric() == False:
            self._errors['contact'] = self.error_class(['Please enter valid contact no'])
        elif string_check.search(contact) != None:
            self._errors['contact'] = self.error_class(['Special character not allowed'])
        elif len(contact) != 10:
            self._errors['contact'] = self.error_class(['Please enter 10 digit contact no'])
       
            
        return self.cleaned_data
        
class SnippetForm(forms.ModelForm):
    class Meta:
        model = Snippet
        fields = ('name','body')
        
    def __init__(self,*args, **kwargs):
        super().__init__(*args,**kwargs)
        
        self.helper = FormHelper
        self.helper.form_method = 'post'
        self.helper.layout = Layout(
            'name','body',Submit('submit','submit',css_class='btn-sucess')
        )
    
class contactHere(forms.ModelForm):
    class Meta:
        model = ContactHere
        fields = ('name','email','message')
        labels = {
            'name': 'Full Name','email':'E-mail'
        }
    def __init__(self,*args, **kwargs):
        super().__init__(*args,**kwargs)
        
        self.helper = FormHelper
        self.helper.form_method = 'post'
        self.helper.layout = Layout(
            'name','email','message',Submit('submit','submit',css_class='btn-sucess')
        )
    
    def clean(self):
        string_check = re.compile('[@_!#$%^&*()<>?/\|}{~:]')
        
        super(contactHere, self).clean()
        name = self.cleaned_data.get('name')
        
        if any(i.isdigit() for i in name) == True:
            self._errors['name'] = self.error_class(['Please enter valid string'])
        elif string_check.search(name) != None:
            self._errors['name'] = self.error_class(['Special character not allowed'])
        elif (len(name.split()) < 2 or len(name.split())>2):
            self._errors['name'] = self.error_class(['Please enter valid full name'])
        
        return self.cleaned_data
        