from django.conf.urls import url
from django.urls import path, include
import rest_framework
from . import views
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.urlpatterns import format_suffix_patterns

urlpatterns = [
    path('api-auth',include("rest_framework.urls")),
    path('',views.contact),
    path('snippet',views.Snippet_details),
    path('career',views.applyHere,name='career'),
    path('applyhere',views.career),
    path('contact',views.Contacthere,name='contact'),
    path('employee',views.Employeeview.as_view())
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
