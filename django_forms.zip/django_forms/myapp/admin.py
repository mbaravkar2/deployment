from django.contrib import admin
from .models import Snippet,Contact,ApplyForm, ContactHere, Employee

admin.site.register(Snippet)
admin.site.register(Contact)
admin.site.register(ApplyForm)
admin.site.register(ContactHere)
admin.site.register(Employee)