from django.db import models
from django.db.models.fields import IntegerField
from .validators import validate_file_extension
# Create your models here.
class Contact(models.Model):
    name = models.CharField(max_length=90)
    email = models.EmailField()
    category = models.CharField(max_length=10,choices=[('Question','question'),('Other','other')],default='question')
    subject = models.CharField(max_length=90)
    body = models.TextField()
    def __str__(self):
        return self.name
        
class Snippet(models.Model):
    name = models.CharField(max_length=90)
    body = models.TextField()
    
    def __str__(self):
        return self.name

class ApplyForm(models.Model):
    full_name = models.CharField(max_length=90)
    father_name = models.CharField(max_length=20)
    qualification = models.CharField(max_length=20)
    email = models.EmailField()
    contact = models.CharField(max_length=12)
    position = models.CharField(max_length=100,choices=[("Intern Trainee Developer(AI)","Intern Trainee Developer(AI)"),("Trainee Developer(AI)","Trainee Developer(AI)"),("Developer(AI)","Developer(AI)"),("Senior Developer(AI)","Senior Developer(AI)"),("Intern Trainee Developer(python)","Intern Trainee Developer(python)"),("Trainee Developer(python)","Trainee Developer(python)"),("Senior Developer(python)","Senior Developer(python)"),("Developer(python)","Developer(python)"),("Intern Trainee Developer(java)","Intern Trainee Developer(java)"),("Trainee Developer(java)","Trainee Developer(java)"),("Senior Developer(java)","Senior Developer(java)"),("Developer(java)","Developer(java)"),("Intern Trainee Developer(mobile app)","Intern Trainee Developer(mobile app)"),("Trainee Developer(mobile app)","Trainee Developer(mobile app)"),("Senior Developer(mobile app)","Senior Developer(mobile app)"),("Developer(mobile app)","Developer(mobile app)"),("Intern Trainee Developer(web app)","Intern Trainee Developer(web app)"),("Trainee Developer(web app)","Trainee Developer(web app)"),("Senior Developer(web app)","Senior Developer(web app)"),("Developer(web app)","Developer(web app)"),("Intern Trainee developer(Games)","Intern Trainee developer(Games)"),("Trainee Developer(Games)","Trainee Developer(Games)"),("senior Developer(Games)","senior Developer(Games)"),("Developer(Games)","Developer(Games)"),("HR Executive","HR Executive"),("HR Recruiter","HR Recruiter"),("HR Manager","HR Manager"),("Sr.HR Executive","Sr.HR Executive"),("Sr.HR Recruiter","Sr.HR Recruiter"),("Sr.HR Manager","Sr.HR Manager")])
    resume = models.FileField(help_text=('.pdf, .doc, .docx, .xlsx, .xls'),validators=[validate_file_extension])
    
    def __str__(self):
        return self.email
    
class ContactHere(models.Model):
    name = models.CharField(max_length=20)
    email = models.EmailField()
    message = models.TextField()
    
    def __str__(self):
        return self.name


class Employee(models.Model):
    firstname = models.CharField(max_length=10)
    last_name = models.CharField(max_length=10)
    emp_id = models.IntegerField()
    
    def __str__(self):
        return self.firstname